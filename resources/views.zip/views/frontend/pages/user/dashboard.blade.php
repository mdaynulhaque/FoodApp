@extends('frontend.layouts.master')

@section('content')
<div class="row">
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2>12</h2>
                                    <p class="m-b-0">Users</p>
                                </div>
                            </div>
                        </div>
                    </div>
					
					 <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2>120</h2>
                                    <p class="m-b-0">Orders</p>
                                </div>
                            </div>
                        </div>
                    </div>
					
                    <div class="col-md-3">
                        <div class="card p-30">
                            <div class="media">
                                <div class="media-left meida media-middle">
                                    <span></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h2>123</h2>
                                    <p class="m-b-0">Customer</p>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
                </div>
@endsection