	<footer id="footer" class="mt-2"><!--Footer-->
		
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="single-widget">
							<h2>Service</h2>
							<ul class="nav navbar-nav">
								<li><a href="{{ route('contact') }}">Online Help</a></li>
								<li><a href="{{ route('contact') }}">Contact Us</a></li>
								<li><a href="{{ route('user.order.history') }}">Order Status</a></li>
								<li><a href="{{ route('user.profile') }}">Change Location</a></li>
								<li><a href="{{ route('contact') }}">FAQ’s</a></li>
							</ul>
						</div>
					</div>
					
					<div class="col-sm-4">
						<div class="single-widget">
							<h2>Policies</h2>
							<ul class="nav navbar-nav">
								<li><a href="">Terms of Use</a></li>
								<li><a href="">Privecy Policy</a></li>
								<li><a href="">Refund Policy</a></li>
								<li><a href="">Billing System</a></li>
								<li><a href="">Ticket System</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="single-widget">
							<h2>About Shopper</h2>
							<ul class="nav navbar-nav">
								<li><a href="">Company Information</a></li>
								<li><a href="">Careers</a></li>
								<li><a href="">Store Location</a></li>
								<li><a href="">Affillate Program</a></li>
								<li><a href="">Copyright</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col">
						<h5 class="" style="text-align: center;">Copyright © 2020 CP Group. All rights reserved.</h5>
					</div>
	
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
